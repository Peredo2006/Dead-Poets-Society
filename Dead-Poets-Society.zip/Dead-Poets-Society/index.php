<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dead Poets Society</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor
  * Updated: Aug 30 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html">Dead Poets Society</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="active" href="#hero">Início</a></li>
          <li><a href="#about">Sobre</a></li>
          <li><a href="#leitura-atual">Leitura Atual</a></li>
          <li><a href= "#livros-lidos">Livros Lidos</a></li>
          <li><a href= "#instagram">Instagram</a></li>
          <li><a href="#monitores-coordenadoras">Monitores e Coordenadoras</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <?php 
      session_start();
      if(isset($_SESSION['usuario'])){
        echo "<div class='menu'>
                <div class='user-info dropdown'>
                  <div class = 'foto-nome'>
                    <div class='user-photo'>
                      <img src='assets/img/foto-perfil.png' alt='Foto do Usuário'>
                    </div>
                    <div class='user-name'>".strtok($_SESSION["nomeusuario"], " ")."</div>
                  </div>
                  <div class='dropdown-content'>
                    <a class='dropdown-item' href='#'>Perfil</a>
                    <a class='dropdown-item' href='#'>Configurações</a>
                    <a class='dropdown-item' href='#' onclick='logout()'>Sair</a>
                  </div>
                </div>
              </div>";
      }else{
        echo "<a href='login.php' class='get-started-btn'>Entrar</a>";
      }
        ?>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-content-center align-items-center">
    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100">
      <h1>Clube de Leitura <br>Dead Poets Society</h1>
      <?php
        if(isset($_SESSION["usuario"])){
          echo "<h2>Bem vindo(a) ao clube, ".strtok($_SESSION["nomeusuario"], " ")."!</h2>";
        }else{
          echo"<h2>Faça parte do melhor clube do IFSP Guarulhos</h2>
          <a href='login.php' class='btn-get-started'>Entrar</a>";
        }
        
      ?>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <h1>Sobre nós....</h1>
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/sobre.jpeg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3>Reuniões às quartas-feiras, das 12h às 13h, na sala G-40</h3>
            <p>
              Nosso nome é inspirado no filme “Sociedade dos Poetas Mortos” (do livro Dead Poets Society, de N. H. Kleinbaum). A ideia inicial foi do estudante Pedro Ribeiro (IFSP-GRU), que conseguiu atrair os primeiros membros no período da pandemia de COVID-19. Desde sua criação, foram mais de 25 livros lidos! <br>
              Até o final de 2022, os encontros ocorriam de forma online aos sábados, porém, a participação foi diminuindo conforme fomos retornando à “vida normal”. Por isso, foi decidido, para o ano de 2023, mudar esse formato para encontros presenciais. Aos estudantes e servidores do câmpus, que desejem conhecer ou integrar nosso clube, um lembrete: esse clube não tem nada a ver com o clube de leitura das aulas de português: não existe obrigação de produzir trabalhos e ninguém é avaliado com notas ou conceitos. É “só” ler, ampliar repertório em gêneros e autores da literatura, compartilhar experiências e desfrutar do prazer de fazer parte de uma comunidade de leitores
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    
    <!-- ======= Leitura Atual Section ======= -->
    <section id="leitura-atual" class="about">
      <div class="container" data-aos="fade-up">
        <h1>Leitura Atual</h1>
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
          <h3>A Sucessora</h3>
          <p><b>Autora: </b>Carolina Nabuco</p>
          <p><b>Ano de publicação: </b>1934</p>
          <p><b>Sinopse: </b>A sucessora une prosa intimista e psicológica ao dar voz a uma protagonista feminina: Marina, uma jovem recém-casada que após uma romântica lua de mel muda-se para a mansão do marido, o milionário Roberto Steen. Ao entrar em sua nova residência, depara-se com um imponente retrato de Alice, a primeira mulher de Roberto, falecida poucos meses antes de Marina e ele se conhecerem. Alice era dona de uma personalidade exuberante e um ícone da sociedade carioca, enquanto Marina, criada na fazenda da família, sempre levou uma vida simples e distante dos costumes liberais da cidade grande. Marina é então invadida por sentimentos de insegurança e inadequação. Afinal, numa vida em que todos – involuntariamente ou nem tanto – a comparam à primeira Madame Steen, será que seu amor por Roberto resistirá ao fantasma de uma mulher tão especial?<br>
          A sucessora é um romance envolvente escrito por Carolina Nabuco, uma das primeiras mulheres brasileiras a atuar como escritora. Publicado em 1934, alcançou grande sucesso editorial, recebendo várias reedições no Brasil. Em 1941, com o Oscar de melhor filme para Rebecca, a mulher inesquecível, do diretor Alfred Hitchcock, um debate internacional teve início: o romance que inspirou o filme, da inglesa Daphne du Maurier, publicado em 1938, teria sido plágio de A sucessora. A semelhança entre os romances foi reconhecida por críticos literários da época, e não se trata de mera coincidência: antes da publicação, Carolina Nabuco enviou ao agente literário da escritora inglesa os originais de seu livro, traduzidos por ela mesma para o inglês. Nabuco, contudo, preferiu evitar conflitos judiciais.<br>
          Décadas mais tarde, a narrativa de A sucessora foi adaptada para o formato de telenovela por Manoel Carlos e exibida com sucesso pela Rede Globo entre 1978 e 1979, tendo Susana Vieira no papel de Marina.</p>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <img src="assets/img/a-sucessora.jpg" class="img-fluid" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Leitura atual Section -->

    <!-- ======= Livros Lidos ======= -->
    <section id="livros-lidos" class="trainers">
      <div class="container" data-aos="fade-up">
        <h1>Livros Lidos</h1>
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/1984.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>1984 - Geroge Orwell (1949)</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/e-não-sobrou-nenhum.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>E não sobrou nenhum - Agatha Christie (1939)</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/pequeno-principe.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>O pequeno príncipe - Antoine De Saint-Exupéry (1943)</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container" data-aos="fade-up">
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/um-estudo-em-vermelho.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Um estudo em vermelho - Arthur Conan Doyle (1887)</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/alienista.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>O Alienista - Machado de Assis (1882)</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/hobbit.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>O Hobbit - J. J. R. Tolkien (1937)</h3>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Livros Lidos -->

    <!--Instagram-->
    <section id="instagram">
      <div class="container" data-aos="fade-up">
        <h1>Instagram</h1>
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
          <a href="https://www.instagram.com/deadpoetssocietyifsp/" target="_blank">
            <img src="assets/img/instagram.png">
          </a>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <p>
              Criamos essa conta, com o intuito de divulgar nosso trabalho para cada vez mais pessoas. Esperamos, por meio do Instagram, compartilhar diversas coisas: fotos de nossas reuniões, os livros que estamos lendo no momento, posts sobre leitura e MUITO mais. Então, fique ligado, para não perder nada! <br>
              Clique no ícone ao lado para acessar nossa página!
            </p>
          </div>
        </div>

      </div>
    </section>
    <!--End Instagram-->

        <!-- ======= Monitores e Coordenadoras ======= -->
        <section id="monitores-coordenadoras" class="trainers">
      <div class="container" data-aos="fade-up">
        <h1>Monitores e Coordenadoras</h1>
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/ana.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Ana Caroline - Monitora</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/mariana.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Mariana Amorim - Monitora</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/pedro.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Pedro Santos - Monitor</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="container" data-aos="fade-up">
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/gema.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Gema Galgani - Coordenadora</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/lidia.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h3>Lídia Souza - Coordenadora</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Monitores e Coordenadoras  -->

  </main><!-- End #main -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script>         
    function logout() {
      <?php session_destroy(); ?>
      window.location.href = 'index.php';
    }

    (function() {
      "use strict";
    
      /**
       * Easy selector helper function
       */
      const select = (el, all = false) => {
        el = el.trim()
        if (all) {
          return [...document.querySelectorAll(el)]
        } else {
          return document.querySelector(el)
        }
      }
    
      /**
       * Easy event listener function
       */
      const on = (type, el, listener, all = false) => {
        let selectEl = select(el, all)
        if (selectEl) {
          if (all) {
            selectEl.forEach(e => e.addEventListener(type, listener))
          } else {
            selectEl.addEventListener(type, listener)
          }
        }
      }
    
      /**
       * Easy on scroll event listener 
       */
      const onscroll = (el, listener) => {
        el.addEventListener('scroll', listener)
      }
    
      /**
       * Back to top button
       */
      let backtotop = select('.back-to-top')
      if (backtotop) {
        const toggleBacktotop = () => {
          if (window.scrollY > 100) {
            backtotop.classList.add('active')
          } else {
            backtotop.classList.remove('active')
          }
        }
        window.addEventListener('load', toggleBacktotop)
        onscroll(document, toggleBacktotop)
      }
    
      /**
       * Mobile nav toggle
       */
      on('click', '.mobile-nav-toggle', function(e) {
        select('#navbar').classList.toggle('navbar-mobile')
        this.classList.toggle('bi-list')
        this.classList.toggle('bi-x')
      })
    
      /**
       * Mobile nav dropdowns activate
       */
      on('click', '.navbar .dropdown > a', function(e) {
        if (select('#navbar').classList.contains('navbar-mobile')) {
          e.preventDefault()
          this.nextElementSibling.classList.toggle('dropdown-active')
        }
      }, true)
    
      /**
       * Preloader
       */
      let preloader = select('#preloader');
      if (preloader) {
        window.addEventListener('load', () => {
          preloader.remove()
        });
      }
    
      /**
       * Testimonials slider
       */
      new Swiper('.testimonials-slider', {
        speed: 600,
        loop: true,
        autoplay: {
          delay: 5000,
          disableOnInteraction: false
        },
        slidesPerView: 'auto',
        pagination: {
          el: '.swiper-pagination',
          type: 'bullets',
          clickable: true
        },
        breakpoints: {
          320: {
            slidesPerView: 1,
            spaceBetween: 20
          },
        
          1200: {
            slidesPerView: 2,
            spaceBetween: 20
          }
        }
      });
    
      /**
       * Animation on scroll
       */
      window.addEventListener('load', () => {
        AOS.init({
          duration: 1000,
          easing: 'ease-in-out',
          once: true,
          mirror: false
        })
      });
    
      /**
       * Initiate Pure Counter 
       */
      new PureCounter();
    
    })()
  </script>

</body>

</html>