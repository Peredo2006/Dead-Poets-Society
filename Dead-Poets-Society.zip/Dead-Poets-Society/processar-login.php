<?php
require_once "conexao.php";

$email = $_POST["email"];
$senha = $_POST["senha"];


$sql = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
$result = $conn->query($sql);
$row = $result -> fetch_assoc();

if ($result->num_rows == 1) {
    session_start();
    $_SESSION["usuario"] = true;
    $_SESSION["nomeusuario"] = $row["nome"];
    header("Location: index.php");
    exit();
} else {
    header("Location: login.php?erro=1");
    exit();
}

$conn->close();
?>
