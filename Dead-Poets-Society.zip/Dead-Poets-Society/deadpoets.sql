create database deadpoets;
use deadpoets;

create table usuario(
nome varchar(100),
email varchar (300) primary key,
telefone varchar (50), 
senha varchar (50));

select * from usuario;